
<body bgcolor="" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" offset="0" style="padding:70px 0 70px 0;">
<table width="600" height="auto" align="center" cellpadding="0" cellspacing="0" style="background-color:; border:; border-radius:3px !important;">
    <tr>
        <td width="600" height="auto" bgcolor="#367fd3" border="0" style="padding:6px 28px; display:block; margin: 0px auto;">
            <a href="https://tyronpay.com" target="_blank"  style="display: block; height: ; width:; margin-left: ; margin-right: ; max-width:; min-width:; text-align: center; text-decoration:none;">
                <h1 style="font-weight: 800;  color:#fff;" >Tyronpay</h1>
            </a>
        </td>
    </tr>
    <tr>
        <td width="600" bgcolor="" border="0" style="color:#737373; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; font-size:14px; line-height:150%; text-align:left; padding:48px;">

            <p style="margin:0 0 16px;">Hello Admin {{$rece}}.</p>
           
            <p style="margin:0 0 16px;">{!!$details!!}</p>
            <!--  <p style="margin:0 0 16px;"> Regards,  <strong> {{ $emailsender ?? 'Support' }} -->
            </strong></p>
            <p>Thank You. <br>
            Tyronpay support team.</p>
        </td>
    </tr>
    <tr>
        <td width="" height="80" bgcolor="#1e314a" border="0" style=" width: 90%; padding:6px 36px;  display:block; margin: 0px auto;">
            <p style="color: #fff; text-align: center; margin-top: -4px;">
                © 2023 Tyronpay All Rights Reserved
            </p>
        </td>
    </tr>
</table>
<style type="text/css">
    .contact-btn{
        position: relative;
        z-index: 0;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        height: 22px;
        font-weight: 600;
        color: #fff;
        background: #f8941d;
        border-radius: 24px;
        padding: 2px 5px;
        z-index: 0;
        /*border: 2px solid #f8941d;*/
        text-decoration: none;


    }
</style>
</body>
