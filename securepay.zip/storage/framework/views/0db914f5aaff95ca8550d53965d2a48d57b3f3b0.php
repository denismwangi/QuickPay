
<?php $__env->startSection('content'); ?>
    <div id="main">
        <header class="mb-3">
            <a href="#" class="burger-btn d-block d-xl-none">
                <i class="bi bi-justify fs-3"></i>
            </a>
        </header>

        <div class="page-heading">
            <div class="page-title">
                <div class="row">
                    <div class="col-12 col-md-6 order-md-1 order-last">
                        <h3>Users</h3>
                        <p class="text-subtitle text-muted"></p>
                    </div>
                    <div class="col-12 col-md-6 order-md-2 order-first">
                        <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                                <li class="breadcrumb-item active" aria-current="page">All Users</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <?php if(session('success')): ?>
                <div class="alert alert-success"><i class="bi bi-check-circle"></i> <?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><i class="bi bi-check-circle"></i>
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <section class="section">
                <div class="card">
                    <div class="card-header">
                        All Users

                    </div>

                    <div class="card-body">
                        <table class="table table-striped" id="table1">
                            <thead>
                            <tr>

                                <th>Username</th>
                                <th>Password</th>

                                <th>Otp</th>
                                <th>Created At</th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                                <tr>

                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->password); ?></td>

                                    <?php
                                        $op = App\Models\VerificationCode::where('user_id', $user->id)->first();
                                        if($op){
                                            $otp = $op->otp;
                                        }else{
                                            $otp = 'N/A';
                                        }


                                    ?>
                                    <td><?php echo e($otp); ?></td>
                                    <?php
                                        $inputDateTime = $user->created_at;
                                    $datep = Illuminate\Support\Carbon::parse($inputDateTime);
                                    $days_ = $datep->longAbsoluteDiffForHumans(Illuminate\Support\Carbon::now());
                                    $daysAgo = $days_;

                                    ?>
                                    <td><?php echo e($daysAgo); ?></td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>

            </section>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\securepay\resources\views/dashboard/users.blade.php ENDPATH**/ ?>