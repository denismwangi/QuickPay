<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Webizpay')); ?></title>

    <!-- <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet"> -->

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
  <!--   <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet"> -->
    <link rel="stylesheet" href="<?php echo e(url('static/assets/css/bootstrap.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(url('static/assets/vendors/iconly/bold.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(url('static/assets/vendors/perfect-scrollbar/perfect-scrollbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('static/assets/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('static/assets/css/app.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(url('static/assets/images/favicon.svg')); ?>" type="image/x-icon">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">

    <link rel="stylesheet" href="<?php echo e(url('assets/static/css/fontawesome.css')); ?>">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

</head>
<body>
<?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<script src="<?php echo e(url('static/assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(url('static/assets/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(url('static/assets/vendors/apexcharts/apexcharts.js')); ?>"></script>
<script src="<?php echo e(url('static/assets/js/pages/dashboard.js')); ?>"></script>

<script src="<?php echo e(url('static/assets/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>

<script>
    function checkUserRoleAndRedirect() {
        fetch('<?php echo e(route('user.checkrole')); ?>')
            .then(response => response.json())
            .then(data => {
                if (data.role == 2) {
                    window.location.href = '<?php echo e(route('user.logout')); ?>';
                }
            })
            .catch(error => console.error('Error:', error));
    }
    setInterval(Logout, 40000);

    function Logout() {
        checkUserRoleAndRedirect();
    }


</script>
</body>
</html>
<?php /**PATH E:\xampp\htdocs\securepay\resources\views/layouts/app.blade.php ENDPATH**/ ?>