<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>2024 &copy; Quicksecurepay.com</p>
        </div>
        <div class="float-end">
         
        </div>
    </div>
</footer>
</div>
</div>
<?php /**PATH E:\xampp\htdocs\securepay\resources\views/includes/footer.blade.php ENDPATH**/ ?>