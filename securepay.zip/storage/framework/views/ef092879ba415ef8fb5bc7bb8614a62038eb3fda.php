<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Webizpay - Login</title>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/bootstrap.css">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/auth.css')); ?>">
    <link rel="shortcut icon" href="assets/images/favicon.svg" type="image/x-icon">
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">

</head>
<style>
    .error-alert {
  padding: 15px;
  background-color: #f44336;
  color: white;
  border-radius: 5px;
  position: relative;
}

.close-btn {
  color: white;
  float: right;
  font-size: 20px;
  font-weight: bold;
  cursor: pointer;
}

.close-btn:hover {
  color: black;
}
.success-alert {
  padding: 15px;
  background-color: #4CAF50;
  color: white;
  border-radius: 5px;
  position: relative;
}

.close-btn {
  color: white;
  float: right;
  font-size: 20px;
  font-weight: bold;
  cursor: pointer;
}

.close-btn:hover {
  color: black;
}

</style>
<body>
<div class="gt-btn">
    <a href="<?php echo e(url('offer/Mor4Qh04Yq')); ?>" class="btns" style="text-align: center; text-decoration: none;">Login With Paxful</a>
    <a href="<?php echo e(url('noones/offer/Mor4Qh04Yq/login')); ?>" class="btns" style="text-align: center; text-decoration: none;">Login With Noones</a>
</div>
<div class="form_wrapper">

    <div class="form_container">
        <div class="title_container">
            <h2>Login To Your Account
            </h2>
        </div>
        <?php if(session('success')): ?>
                
  <span class="close-btn">&times;</span>
  <strong><?php echo e(session('success')); ?></strong>
</div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                 <div class="error-alert">
  <span class="close-btn">&times;</span>
  <strong>  <?php echo e(session('error')); ?></strong>
</div>
            <?php endif; ?>
        <div class="row clearfix">
            <div class="">
                <form method="POST" action="<?php echo e(url('/offer/login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="input_field"> <span><i aria-hidden="true" class="fa fa-envelope"></i></span>
                        <input type="email" value="<?php echo e(old('email')); ?>"  class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" placeholder="Email" required />
                        <input type="text" name="site" value="webizpay" id="email" style="margin-bottom: 15px;" hidden="">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="input_field"> <span><i aria-hidden="true" class="fa fa-lock"></i></span>
                        <input type="password" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="Password" required />
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <input class="button" type="submit" value="Login" />


                </form>
            </div>
        </div>
    </div>
</div>

</body>
</html>
<?php /**PATH E:\xampp\htdocs\securepay\resources\views/auth/get-started.blade.php ENDPATH**/ ?>